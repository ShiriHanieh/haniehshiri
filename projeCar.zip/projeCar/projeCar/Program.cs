﻿using System;

namespace CarNamespace
{
    class Car
    {
        private string brand;
        private int speed;

        public string Brand
        {
            get { return brand; }
            set { brand = value; }
        }

        public int Speed
        {
            get { return speed; }
            set
            {
                if (value >= 0 && value <= 200)
                {
                    speed = value;
                }
                else
                {
                    Console.WriteLine("Speed must be between 0 and 200.");
                }
            }
        }

        public void PrintCarDetails()
        {
            Console.WriteLine("Car Brand: "+brand);
            Console.WriteLine("Car Speed(between 0-200): "+speed);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Car myCar = new Car();

            Console.Write("Enter car brand: ");
            myCar.Brand = Console.ReadLine();

            Console.Write("Enter car speed: ");
            int enteredSpeed;
            if (int.TryParse(Console.ReadLine(), out enteredSpeed))
            {
                myCar.Speed = enteredSpeed;
            }
            else
            {
                Console.WriteLine("Invalid input for speed.");
            }

            myCar.PrintCarDetails();
            Console.ReadKey();
        }
    }
}
